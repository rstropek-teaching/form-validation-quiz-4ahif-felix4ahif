"use strict";
window.onclick = function () {
    proofFields();
};
function proofFields() {
    if (document.getElementById("firstName").value != "") {
        document.getElementById("firstNameMandatory").style.display = "none";
    }
    else {
        document.getElementById("firstNameMandatory").style.display = "block";
    }
    if (document.getElementById("lastName").value != "") {
        document.getElementById("lastNameMandatory").style.display = "none";
    }
    else {
        document.getElementById("lastNameMandatory").style.display = "block";
    }
    if (document.getElementById("email").value != "") {
        document.getElementById("emailMandatory").style.display = "none";
    }
    else {
        document.getElementById("emailMandatory").style.display = "block";
    }
}
