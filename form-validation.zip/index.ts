



window.onclick = () => {
    proofFields();
}

function proofFields(){
    if((<HTMLInputElement>document.getElementById("firstName")).value != ""){
        (<HTMLInputElement>document.getElementById("firstNameMandatory")).style.display = "none";
    }else{
        (<HTMLInputElement>document.getElementById("firstNameMandatory")).style.display = "block";
    }
    if((<HTMLInputElement>document.getElementById("lastName")).value != ""){
        (<HTMLInputElement>document.getElementById("lastNameMandatory")).style.display = "none";
    }else{
        (<HTMLInputElement>document.getElementById("lastNameMandatory")).style.display = "block";
    }
    if((<HTMLInputElement>document.getElementById("email")).value == "" && (<HTMLInputElement>document.getElementById("newsletter")).value){
        (<HTMLInputElement>document.getElementById("emailMandatory")).style.display = "none";
    }else{
        (<HTMLInputElement>document.getElementById("emailMandatory")).style.display = "block";
    }
}

